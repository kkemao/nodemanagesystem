
$(function () {
   
    $IF.getUserInfo();
    initUserInfo();
    }
)