"use strict"
$(function(){
    //左侧菜单
var contents = [
    {"contentOneLevel":"基础产品","subContent":["人脸属性过滤","数据挖掘","GIS应用","视频比对分析","警务APP"]},
    {"contentOneLevel":"垂直行业应用","subContent":["综合人像治理平台","公交立体防控系统","行人闯红灯系统","616人员管理系统","机场人员安检分析系统","口岸旅检人像应用平台","监区人员监控系统"]},
    {"contentOneLevel":"预研DEMO","subContent":["人体结构化应用","基于视频流内的实时告警","视频质量检测工具"]},
    {"contentOneLevel":"产品性能参数","subContent":["结构化引擎","布控引擎","搜索引擎"]},
];
//图片列表和内容
var containerCcontent = [
    {"img":"./img/2.1.png","title":"旅检人员智能人像演示系统","des":"该应用可接入实时视频流，对视频流中的人员进行实时识别，对染疫人员、水客前科、高频次往返人员进行实时识别，并在视频流中进行打框标注","newIconShow":"1","video":"movie.ogg","alt":"图片","ID":"0"},
    {"img":"./img/4.1.png","title":"人体结构化演示","des":"该应用可接入多路实时视频流，对视频流中的人体进行采集，并支持对采集人体的拖拽以图搜图","newIconShow":"1","video":"./img/6.jpg","alt":"图片","ID":"1"},
    {"img":"./img/5.png","title":"视频质量检测工具","des":"Window 64位免安装软件，可同时多个视频文件、在线视频流进行视频质量分析，通过算法检测和分析判断视频中符合识别要求人脸，给出视频质量分数","newIconShow":"1","video":"movie.ogg","alt":"图片","ID":"2"},
    // {"img":"./img/container-content04.png","title":"电动车检测DEMO","des":"对单路在线视频流进行电动车的实时检测的演示系统，通过对输入的视频流进行解码抽帧，利用算法模型完成电动车检测和跟踪，将视频中的电动车在web界面识别出来","newIconShow":"1","video":"movie.ogg","alt":"图片","ID":"3"},
    {"img":"./img/3.png","title":"场馆安保应用","des":"【应用场景】针对大型场馆安保活动，落实每个观众的实名信息，实现对人数的精确统计，并且对重点人员进行实时比对告警","newIconShow":"1","video":"movie.ogg","alt":"图片","ID":"3"},
    {"img":"./img/lcry.png","title":"流窜人员挖掘","des":"【应用场景】针对涉毒、涉黄、涉毒人员流窜作案的挖掘","newIconShow":"1","video":"movie.ogg","alt":"图片","ID":"4"},
    {"img":"./img/pfcr.png","title":"频繁出入人员挖掘","des":"【应用场景】识别在某一场所经常出入的人员，过滤从业人员，发现新的黄赌毒人员","newIconShow":"1","video":"movie.ogg","alt":"图片","ID":"5"},
    {"img":"./img/qkry.png","title":"前科人员进入场所预警","des":"【应用场景】对前科人员再次出入重点场所进行关注","newIconShow":"1","video":"movie.ogg","alt":"图片","ID":"6"},
    {"img":"./img/dqkry.png","title":"多名前科人员进入同一场所告警","des":"【应用场景】对于聚众赌博、聚众吸毒、涉黄等前科人员进行管控","newIconShow":"1","video":"movie.ogg","alt":"图片","ID":"7"},
    {"img":"./img/rllyc.png","title":"人流量异常告警","des":"【应用场景】民警通过辖区内人脸总数排行，可以了解需要重点关注的场所；针对具体场所，可以查看人数异常告警","newIconShow":"1","video":"movie.ogg","alt":"图片","ID":"8"},
    {"img":"./img/container-content08.png","title":"入境人员非法从业分析","des":"【应用场景】针对辖区内持非从业签证人员从事非法从业活动的挖掘","newIconShow":"1","video":"movie.ogg","alt":"图片","ID":"9"},
    // {"img":"./img/3.png","title":"场馆安保应用","des":"【应用场景】针对大型场馆安保活动，落实每个观众的实名信息，实现对人数的精确统计，并且对重点人员进行实时比对告警","newIconShow":"1","video":"movie.ogg","alt":"图片","ID":"10"},
];
let contentsDom = "";
for(let item of contents ){
       var subcontentDom = '';
      for(let subItem of item.subContent){
        subcontentDom += `
        <dd>${subItem}</dd>
        `;
      }
    contentsDom +=`
    <dl>
        <dt><i class=""></i>${item.contentOneLevel}</dt>
         ${subcontentDom}
       
    </dl>
    `;
}
$('.container-aside').append(contentsDom);
let stringDom = '';
for(var item of containerCcontent){
    stringDom += `
            <li class='container-content-item'>
            <div class="container-content-item-imgcontainer">
                <img src="${item.img}"  v-url="${item.video}" v-index="${item.ID}" alt="${item.alt}"/>
                <i class="${item.newIconShow==1?'new-tip':''}"></i>
            </div>
        <h3>${item.title}</h3>
        <p class="container-content-item-gray"><i></i>${item.des}</p>
        <div class="container-content-item-view">
            <span class="view">0</span>
            <span class="msgIcon">0</span>
        </div>
        </li>
    `;
}
 $('.container-content>ul').html(stringDom);



 let projectModal = [
    {"projectName":"旅检人员智能人像演示系统","scene":"无",
    "func":"该应用可接入实时视频流，对视频流中的人员进行实时识别，对染疫人员、水客前科、高频次往返人员进行实时识别，并在视频流中进行打框标注",
    "attention":"目前在视频中暂时只支持显示英文字符","onlineTime":"6月28日","developer":"王健、曾科凡、陈建、陈信、黄建斌","src":"./video/20180628_204810.mp4","showImg":"0"},


    {"projectName":"人体结构化演示","scene":"无",
     "func":"该应用可接入多路实时视频流，对视频流中的人体进行采集，并支持对采集人体的拖拽以图搜图<br/>演示地址：http://192.168.11.188/ifaas/WebClient/71.html <br/>用户名：test123   密码test123",
     "attention":"目前搜索准确度还有待提升，仅供功能演示使用","onlineTime":"2018年7月4日","developer":"付凌志、刘国伟、王健、曾颖杰、吕旭涛、陈卓州、刘涛","src":"./img/6.jpg","showImg":"1"},


    {"projectName":"视频质量检测工具","scene":"无",
     "func":"Window 64位免安装软件，可同时多个视频文件、在线视频流进行视频质量分析，通过算法检测和分析判断视频中符合识别要求人脸，给出视频质量分数",
     "attention":"该软件需license授权，当前在UI优化阶段","onlineTime":"待定","developer":"刘涛、曾颖杰","src":"./img/3.1.png","showImg":"1"},


    // {"projectName":"电动车检测DEMO","scene":"无",
    //  "func":"对单路在线视频流进行电动车的实时检测的演示系统，通过对输入的视频流进行解码抽帧，利用算法模型完成电动车检测和跟踪，将视频中的电动车在web界面识别出来",
    //  "attention":"当前处于算法效果验证阶段，未深入到业务应用","onlineTime":"5月初完成第一版模型现场测试，6月底发布第二版模型到现场测试","developer":"付凌志（算法）、曾颖杰、刘涛、万历","src":"movie.ogg","showImg":"0"},
    
    
    {"projectName":"场馆安保应用","scene":"针对大型场馆安保活动，落实每个观众的实名信息，实现对人数的精确统计，并且对重点人员进行实时比对告警",
    "func":"通过第三方推送的实时人像、身份证照片、票面座位信息，将身份证号与在逃库身份证号进行比对，比中则产生告警信息；落实票面的座位信息，并在场馆示意图上展示每个区域的实到人数和总人数；人员入场的实时比对信息在界面上动态刷新显示",
    "attention":"无","onlineTime":"2018年7月18日","developer":"王成、丁昌庆、尹鹏","src":"./img/3.png","showImg":"1"},

     {"projectName":"流窜人员挖掘","scene":"针对涉毒、涉黄、涉毒人员流窜作案的挖掘",
     "func":"在辖区类范围内，10天内有5天以上出现在1个或者多个重点场所的人员进行分析，并支持对人员进行打标签，人员类型分类显示（未分类/涉毒/涉黄/涉赌/快递/保洁/其他），人员身份落地",
     "attention":"无","onlineTime":"2018年7月4日","developer":"王成、丁昌庆、尹鹏","src":"./video/流窜人员挖掘.jpg","showImg":"1"},

     {"projectName":"频繁出入人员挖掘 ","scene":"识别在某一场所经常出入的人员，过滤从业人员，发现新的黄赌毒人员",
     "func":"分析出20天内有10天以上出现在该场所的人员,可对经常出入该场所的人员进行打标签（未分类/涉毒/涉黄/涉赌/快递/保洁/其他），过滤掉从业人员后即剩余需要重点关注的对象；并支持对未确认身份人员进行静态融合身份落地",
     "attention":"无","onlineTime":"2018年7月4日","developer":"王成、丁昌庆、尹鹏","src":"./video/频繁出入人员.mp4","showImg":"0"},

     {"projectName":"前科人员进入场所预警","scene":"对前科人员再次出入重点场所进行关注",
     "func":"对辖区内的黄、赌、毒前科人员进行管控，场所内摄像机抓拍的人员与前科相似度达到93%以上（可调）则产生告警，告警信息会通过社区警务APP推送到辖区民警。辖区民警可以根据其出现的历史记录和频率确定是否需要对其出警",
     "attention":"无","onlineTime":"2018年7月4日","developer":"王成、丁昌庆、尹鹏","src":"./video/前科人员进入场所预警.mp4","showImg":"0"},

     {"projectName":"多名前科人员进入同一场所告警","scene":"对于聚众赌博、聚众吸毒、涉黄等前科人员进行管控",
     "func":"多个前科人员在一周内任意30分钟内到达同一场所则告警。分别为涉黄2人在30分钟内到达同一场所则告警，涉毒2人，涉赌3人。 默认相似度93%（可调）",
     "attention":"无","onlineTime":"2018年7月4日","developer":"王成、丁昌庆、尹鹏","src":"./video/多前科人员协同告警.jpg","showImg":"1"},

     {"projectName":"人流量异常告警","scene":"民警通过辖区内人脸总数排行，可以了解需要重点关注的场所；<br/>针对具体场所，可以查看人数异常告警；",
     "func":["以派出所为单位，展现辖区内所有二三类场所人脸总数排序","以派出所为单位，展现辖区内最近1周所有二三类场所人脸总数排序","以场所为单位，展现该场所人脸数24小时内采集变化曲线","以场所为单位，展现该场所最近一月内每日人流量变化曲线、平均曲线、告警曲线;告警曲线=平均曲线x 1.3"],
     "attention":"无","onlineTime":"2018年7月4日","developer":"王成、丁昌庆、尹鹏","src":"./video/人脸数量超平均数预警.mp4","showImg":"0"},

     {"projectName":"入境人员非法从业分析","scene":"针对辖区内持非从业签证人员从事非法从业活动的挖掘",
     "func":["建立持有非从业签证的人员的重点人员库","对每个重点人员进行出行规律分析和统计，对于符合从业规律的人员进行预警"],
     "attention":"无","onlineTime":"2018年7月4日","developer":"王成、丁昌庆、尹鹏","src":"./video/南山上.mp4","showImg":"0"},

     
];
$(".container-content").on("click","img",function(){
    var src = $(this).attr("v-url");
   // $(".project-modal video").attr("src",src)
   var  dataID =$(this).attr("v-Index");
   console.log(dataID);
   upDateModaldata(dataID,projectModal);
    $(".project-modal").show()
    $(".modal-shade").show();

  });
  $(document).click(function (e) {
    if(e.target.className==="modal-shade"){
      $(".modal-shade").css("display","none");
      $(".project-modal").css("display","none");
    }
   });
   $('.project-modal').on("click",".closebtn",function(){
       console.log("dddddddddd")
    $(".modal-shade").css("display","none");
    $(".project-modal").css("display","none");
   })
  
  

//刷新modal 窗口数据的函数
function upDateModaldata(num,dataArr){
    let domString = "";
     let item = dataArr[num];
     console.log(typeof(item));
        var  detail= "";
        var ulList=""
     if(typeof(item.func)=="object"){
       console.log(item.func)
       for(var tt of item.func){
        ulList +=`<li>${tt}</li>`
       }
       detail = ` <ul class="project-update-content">${ulList} </ul>`;
     }else{
       detail=`<p>${item.func}</p>` ;
     }
       
       console.log(item.src)
        domString =`
        <i class="closebtn"></i>
        <div class="project-modal-title">
        <span class="project-name">${item.projectName}</span>
        
      </div>
      <video class="${item.showImg==1?'hide':'show'}" src="${item.src}" controls="controls">
        您的浏览器不支持 video 标签。
      </video>
      <img width="100%" class="${item.showImg==1?'show':'hide'}" src="${item.src}" alt="图片"/>
      <div class="project-modal-info">
      <div class="project-notice">
        <h4>应用场景：</h4>
        <p class="project-notice-content">${item.scene}
        </p>
      </div>
      <div class="project-notice">
        <h4>功能介绍：</h4>
        ${detail}
      </div>
      <div class="project-notice">
        <h4>注意事项：</h4>
        <p class="project-notice-content">${item.attention}
        </p>
      </div>
      <div class="project-notice">
        <h4>上线时间：</h4>
        <p class="project-notice-content">${item.onlineTime}
        </p>
      </div>
      <div class="project-developer">
        <h4>开发人员：</h4>
        <ul class="project-developer-content">
          <li>${item.developer}</li>
        </ul>
      </div>
      <div class="project-comment">
        <h4>评论(0)</h4>
        <textarea name="" id="project-comment-input"></textarea>
        <div class="submit-comment">
          <button>
          <!-- <img src="./img/but_bg.png" alt="提交评论"> -->
          评论
          </button>
        </div>
        <div class="project-comment-content">
          <ul>
            <li>
           
            </li>
          </ul>
        </div>
     
        `;
    
    $(".project-modal").html(domString);
} 
});